/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pencarianbiner;

import java.util.Scanner;
import java.util.ArrayList;
/**
 *
 * @author ananda wahyan
 */
public class PencarianBiner {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner (System.in);
        ArrayList<Integer> test = new ArrayList<>();
        
        
        System.out.println("data angka");
        test.add(13);
        test.add(22);
        test.add(31);
        test.add(45);
        test.add(51);
        test.add(67);
        test.add(72);
        test.add(84);
        test.add(99);
        test.add(107);
  
        for (int i = 0;i<test.size();i++){
            System.out.print(test.get(i)+", ");
        }
        System.out.println("\n");
                
        System.out.print("Cari tempat angka : ");
        int x = sc.nextInt() ;
        boolean ketemu = false;
        int kiri = 0;
        int kanan = test.size();
        
        while(!ketemu && kiri<= kanan){
            int tengah = (kiri+kanan)/2;
            
            if ((int)test.get(tengah) == x){
                ketemu = true;
            }else{
                if(x < (int)test.get(tengah)){
                    kanan = tengah-1;
                }
                if(x > (int)test.get(tengah)){
                   kiri = tengah +1;
                }
            
            }
        if (ketemu){
            System.out.println("posisi x ada di : "+(tengah+1));
        }else{
            tengah = 0;
        }    
            
        }
        if (!ketemu)System.out.println("Angka tidak di temukan");
        
    
}
}
