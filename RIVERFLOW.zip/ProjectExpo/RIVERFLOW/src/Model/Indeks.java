package Model;

public class Indeks {
    private int ind;

    public Indeks(int ind) {
        this.ind = ind;
    }

    public int getInd() {
        return ind;
    }

    public void setInd(int ind) {
        this.ind = ind;
    }
    
}
